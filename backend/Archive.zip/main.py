import os
import joblib
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

# -----------------------
# Paths (EC2 safe)
# -----------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")

# -----------------------
# App
# -----------------------

app = FastAPI(
    title="Veg Price Prediction API",
    version="1.0"
)

# CORS (frontend safe)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------
# In-memory model cache
# -----------------------

MODEL_CACHE = {}

# -----------------------
# Utility functions
# -----------------------

def get_model_path(veg: str, market: str) -> str:
    filename = f"{veg}_{market}.pkl".replace(" ", "_")
    return os.path.join(MODEL_DIR, filename)


def load_model(model_path: str):
    # Cache hit
    if model_path in MODEL_CACHE:
        return MODEL_CACHE[model_path]

    # Load once
    try:
        model = joblib.load(model_path)
        MODEL_CACHE[model_path] = model
        return model
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to load model: {str(e)}"
        )

# -----------------------
# Routes
# -----------------------

@app.get("/")
def root():
    return {"status": "API running"}


@app.get("/models")
def list_models():
    if not os.path.exists(MODEL_DIR):
        return {"count": 0, "models": []}

    models = [
        f.replace(".pkl", "")
        for f in os.listdir(MODEL_DIR)
        if f.endswith(".pkl")
    ]

    return {
        "count": len(models),
        "models": models
    }


@app.get("/predict")
def predict(
    veg: str = Query(..., description="Vegetable key (exact)"),
    market: str = Query(..., description="Market key (exact)"),
    days: int = Query(14, ge=1, le=30, description="Prediction days (1–30)")
):
    model_path = get_model_path(veg, market)

    if not os.path.exists(model_path):
        raise HTTPException(
            status_code=404,
            detail=f"Model not found for veg='{veg}' and market='{market}'"
        )

    model = load_model(model_path)

    try:
        future = model.make_future_dataframe(periods=days)
        forecast = model.predict(future)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Prediction failed: {str(e)}"
        )

    result = (
        forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]]
        .sort_values("ds")
        .tail(days)
        .round(2)
    )

    return {
        "vegetable": veg,
        "market": market,
        "days": days,
        "predictions": result.to_dict(orient="records")
    }
